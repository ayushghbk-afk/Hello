.class public final Landroidx/appcompat/R$drawable;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final abc_ab_share_pack_mtrl_alpha:I = 0x7f080043

.field public static final abc_action_bar_item_background_material:I = 0x7f080044

.field public static final abc_btn_borderless_material:I = 0x7f080045

.field public static final abc_btn_check_material:I = 0x7f080046

.field public static final abc_btn_check_material_anim:I = 0x7f080047

.field public static final abc_btn_check_to_on_mtrl_000:I = 0x7f080048

.field public static final abc_btn_check_to_on_mtrl_015:I = 0x7f080049

.field public static final abc_btn_colored_material:I = 0x7f08004a

.field public static final abc_btn_default_mtrl_shape:I = 0x7f08004b

.field public static final abc_btn_radio_material:I = 0x7f08004c

.field public static final abc_btn_radio_material_anim:I = 0x7f08004d

.field public static final abc_btn_radio_to_on_mtrl_000:I = 0x7f08004e

.field public static final abc_btn_radio_to_on_mtrl_015:I = 0x7f08004f

.field public static final abc_btn_switch_to_on_mtrl_00001:I = 0x7f080050

.field public static final abc_btn_switch_to_on_mtrl_00012:I = 0x7f080051

.field public static final abc_cab_background_internal_bg:I = 0x7f080052

.field public static final abc_cab_background_top_material:I = 0x7f080053

.field public static final abc_cab_background_top_mtrl_alpha:I = 0x7f080054

.field public static final abc_control_background_material:I = 0x7f080055

.field public static final abc_dialog_material_background:I = 0x7f080056

.field public static final abc_edit_text_material:I = 0x7f080057

.field public static final abc_ic_ab_back_material:I = 0x7f080058

.field public static final abc_ic_arrow_drop_right_black_24dp:I = 0x7f080059

.field public static final abc_ic_clear_material:I = 0x7f08005a

.field public static final abc_ic_commit_search_api_mtrl_alpha:I = 0x7f08005b

.field public static final abc_ic_go_search_api_material:I = 0x7f08005c

.field public static final abc_ic_menu_copy_mtrl_am_alpha:I = 0x7f08005d

.field public static final abc_ic_menu_cut_mtrl_alpha:I = 0x7f08005e

.field public static final abc_ic_menu_overflow_material:I = 0x7f08005f

.field public static final abc_ic_menu_paste_mtrl_am_alpha:I = 0x7f080060

.field public static final abc_ic_menu_selectall_mtrl_alpha:I = 0x7f080061

.field public static final abc_ic_menu_share_mtrl_alpha:I = 0x7f080062

.field public static final abc_ic_search_api_material:I = 0x7f080063

.field public static final abc_ic_voice_search_api_material:I = 0x7f080064

.field public static final abc_item_background_holo_dark:I = 0x7f080065

.field public static final abc_item_background_holo_light:I = 0x7f080066

.field public static final abc_list_divider_material:I = 0x7f080067

.field public static final abc_list_divider_mtrl_alpha:I = 0x7f080068

.field public static final abc_list_focused_holo:I = 0x7f080069

.field public static final abc_list_longpressed_holo:I = 0x7f08006a

.field public static final abc_list_pressed_holo_dark:I = 0x7f08006b

.field public static final abc_list_pressed_holo_light:I = 0x7f08006c

.field public static final abc_list_selector_background_transition_holo_dark:I = 0x7f08006d

.field public static final abc_list_selector_background_transition_holo_light:I = 0x7f08006e

.field public static final abc_list_selector_disabled_holo_dark:I = 0x7f08006f

.field public static final abc_list_selector_disabled_holo_light:I = 0x7f080070

.field public static final abc_list_selector_holo_dark:I = 0x7f080071

.field public static final abc_list_selector_holo_light:I = 0x7f080072

.field public static final abc_menu_hardkey_panel_mtrl_mult:I = 0x7f080073

.field public static final abc_popup_background_mtrl_mult:I = 0x7f080074

.field public static final abc_ratingbar_indicator_material:I = 0x7f080075

.field public static final abc_ratingbar_material:I = 0x7f080076

.field public static final abc_ratingbar_small_material:I = 0x7f080077

.field public static final abc_scrubber_control_off_mtrl_alpha:I = 0x7f080078

.field public static final abc_scrubber_control_to_pressed_mtrl_000:I = 0x7f080079

.field public static final abc_scrubber_control_to_pressed_mtrl_005:I = 0x7f08007a

.field public static final abc_scrubber_primary_mtrl_alpha:I = 0x7f08007b

.field public static final abc_scrubber_track_mtrl_alpha:I = 0x7f08007d

.field public static final abc_seekbar_thumb_material:I = 0x7f08007e

.field public static final abc_seekbar_tick_mark_material:I = 0x7f08007f

.field public static final abc_seekbar_track_material:I = 0x7f080080

.field public static final abc_spinner_mtrl_am_alpha:I = 0x7f080081

.field public static final abc_spinner_textfield_background_material:I = 0x7f080082

.field public static final abc_star_black_48dp:I = 0x7f080083

.field public static final abc_star_half_black_48dp:I = 0x7f080084

.field public static final abc_switch_thumb_material:I = 0x7f080085

.field public static final abc_switch_track_mtrl_alpha:I = 0x7f080086

.field public static final abc_tab_indicator_material:I = 0x7f080087

.field public static final abc_tab_indicator_mtrl_alpha:I = 0x7f080088

.field public static final abc_text_cursor_material:I = 0x7f080089

.field public static final abc_text_select_handle_left_mtrl:I = 0x7f08008a

.field public static final abc_text_select_handle_middle_mtrl:I = 0x7f08008b

.field public static final abc_text_select_handle_right_mtrl:I = 0x7f08008c

.field public static final abc_textfield_activated_mtrl_alpha:I = 0x7f08008d

.field public static final abc_textfield_default_mtrl_alpha:I = 0x7f08008e

.field public static final abc_textfield_search_activated_mtrl_alpha:I = 0x7f08008f

.field public static final abc_textfield_search_default_mtrl_alpha:I = 0x7f080090

.field public static final abc_textfield_search_material:I = 0x7f080091

.field public static final btn_checkbox_checked_mtrl:I = 0x7f080172

.field public static final btn_checkbox_checked_to_unchecked_mtrl_animation:I = 0x7f080173

.field public static final btn_checkbox_unchecked_mtrl:I = 0x7f080174

.field public static final btn_checkbox_unchecked_to_checked_mtrl_animation:I = 0x7f080175

.field public static final btn_radio_off_mtrl:I = 0x7f080187

.field public static final btn_radio_off_to_on_mtrl_animation:I = 0x7f080188

.field public static final btn_radio_on_mtrl:I = 0x7f080189

.field public static final btn_radio_on_to_off_mtrl_animation:I = 0x7f08018a

.field public static final test_level_drawable:I = 0x7f0807a0

.field public static final tooltip_frame_dark:I = 0x7f0807ae

.field public static final tooltip_frame_light:I = 0x7f0807af
