.class public final Landroidx/appcompat/R$string;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final abc_action_bar_home_description:I = 0x7f11000a

.field public static final abc_action_bar_up_description:I = 0x7f11000b

.field public static final abc_action_menu_overflow_description:I = 0x7f11000c

.field public static final abc_action_mode_done:I = 0x7f11000d

.field public static final abc_activity_chooser_view_see_all:I = 0x7f11000e

.field public static final abc_activitychooserview_choose_application:I = 0x7f11000f

.field public static final abc_capital_off:I = 0x7f110010

.field public static final abc_capital_on:I = 0x7f110011

.field public static final abc_menu_alt_shortcut_label:I = 0x7f110012

.field public static final abc_menu_ctrl_shortcut_label:I = 0x7f110013

.field public static final abc_menu_delete_shortcut_label:I = 0x7f110014

.field public static final abc_menu_enter_shortcut_label:I = 0x7f110015

.field public static final abc_menu_function_shortcut_label:I = 0x7f110016

.field public static final abc_menu_meta_shortcut_label:I = 0x7f110017

.field public static final abc_menu_shift_shortcut_label:I = 0x7f110018

.field public static final abc_menu_space_shortcut_label:I = 0x7f110019

.field public static final abc_menu_sym_shortcut_label:I = 0x7f11001a

.field public static final abc_prepend_shortcut_label:I = 0x7f11001b

.field public static final abc_search_hint:I = 0x7f11001c

.field public static final abc_searchview_description_clear:I = 0x7f11001d

.field public static final abc_searchview_description_query:I = 0x7f11001e

.field public static final abc_searchview_description_search:I = 0x7f11001f

.field public static final abc_searchview_description_submit:I = 0x7f110020

.field public static final abc_searchview_description_voice:I = 0x7f110021

.field public static final abc_shareactionprovider_share_with:I = 0x7f110022

.field public static final abc_shareactionprovider_share_with_application:I = 0x7f110023

.field public static final abc_toolbar_collapse_description:I = 0x7f110024

.field public static final search_menu_title:I = 0x7f11060f
