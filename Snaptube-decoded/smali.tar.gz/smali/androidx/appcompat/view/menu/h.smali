.class public interface abstract Landroidx/appcompat/view/menu/h;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/h$a;
    }
.end annotation


# virtual methods
.method public abstract b(Landroidx/appcompat/view/menu/MenuBuilder;)V
.end method
