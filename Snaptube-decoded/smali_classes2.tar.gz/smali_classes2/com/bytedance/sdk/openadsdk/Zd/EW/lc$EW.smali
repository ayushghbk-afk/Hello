.class Lcom/bytedance/sdk/openadsdk/Zd/EW/lc$EW;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/bytedance/sdk/openadsdk/Zd/EW/lc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "EW"
.end annotation


# static fields
.field private static final EW:Lcom/bytedance/sdk/openadsdk/Zd/EW/lc;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lcom/bytedance/sdk/openadsdk/Zd/EW/lc;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lcom/bytedance/sdk/openadsdk/Zd/EW/lc;-><init>(Lcom/bytedance/sdk/openadsdk/Zd/EW/lc$1;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lcom/bytedance/sdk/openadsdk/Zd/EW/lc$EW;->EW:Lcom/bytedance/sdk/openadsdk/Zd/EW/lc;

    .line 8
    .line 9
    return-void
.end method

.method public static synthetic EW()Lcom/bytedance/sdk/openadsdk/Zd/EW/lc;
    .locals 1

    .line 1
    sget-object v0, Lcom/bytedance/sdk/openadsdk/Zd/EW/lc$EW;->EW:Lcom/bytedance/sdk/openadsdk/Zd/EW/lc;

    .line 2
    .line 3
    return-object v0
.end method
