.class final Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source ""

# interfaces
.implements Lo/c74;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;->S(Landroidx/lifecycle/LifecycleCoroutineScope;Lcom/snaptube/extractor/pluginlib/models/VideoInfo;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lo/c74;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n\u00a2\u0006\u0004\u0008\u0002\u0010\u0003"
    }
    d2 = {
        "Lo/cr1;",
        "Lo/xhb;",
        "<anonymous>",
        "(Lo/cr1;)V"
    }
    k = 0x3
    mv = {
        0x2,
        0x0,
        0x0
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.snaptube.plugin.extension.chooseformat.subtitles.SubtitleChoiceViewModel$initData$1"
    f = "SubtitleChoiceViewModel.kt"
    i = {}
    l = {}
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $isMovie:Z

.field final synthetic $videoInfo:Lcom/snaptube/extractor/pluginlib/models/VideoInfo;

.field label:I

.field final synthetic this$0:Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;


# direct methods
.method public constructor <init>(Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;Lcom/snaptube/extractor/pluginlib/models/VideoInfo;ZLkotlin/coroutines/Continuation;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;",
            "Lcom/snaptube/extractor/pluginlib/models/VideoInfo;",
            "Z",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->this$0:Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;

    iput-object p2, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->$videoInfo:Lcom/snaptube/extractor/pluginlib/models/VideoInfo;

    iput-boolean p3, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->$isMovie:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lo/xhb;",
            ">;"
        }
    .end annotation

    new-instance p1, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;

    iget-object v0, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->this$0:Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;

    iget-object v1, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->$videoInfo:Lcom/snaptube/extractor/pluginlib/models/VideoInfo;

    iget-boolean v2, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->$isMovie:Z

    invoke-direct {p1, v0, v1, v2, p2}, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;-><init>(Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;Lcom/snaptube/extractor/pluginlib/models/VideoInfo;ZLkotlin/coroutines/Continuation;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lo/cr1;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->invoke(Lo/cr1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lo/cr1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lo/cr1;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lo/xhb;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p1

    check-cast p1, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;

    sget-object p2, Lo/xhb;->a:Lo/xhb;

    invoke-virtual {p1, p2}, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    .line 1
    invoke-static {}, Lo/o85;->f()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    iget v0, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->label:I

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Lkotlin/c;->b(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->this$0:Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;

    .line 12
    .line 13
    iget-object v0, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->$videoInfo:Lcom/snaptube/extractor/pluginlib/models/VideoInfo;

    .line 14
    .line 15
    invoke-virtual {v0}, Lcom/snaptube/extractor/pluginlib/models/VideoInfo;->getSubtitles()Ljava/util/List;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const-string v1, "getSubtitles(...)"

    .line 20
    .line 21
    invoke-static {v0, v1}, Lo/n85;->f(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iget-boolean v1, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->$isMovie:Z

    .line 25
    .line 26
    invoke-static {p1, v0, v1}, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;->s(Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;Ljava/util/List;Z)Ljava/util/List;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iget-object v0, p0, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel$initData$1;->this$0:Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;

    .line 31
    .line 32
    invoke-static {v0}, Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;->A(Lcom/snaptube/plugin/extension/chooseformat/subtitles/SubtitleChoiceViewModel;)Lo/k17;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {v0, p1}, Lo/k17;->m(Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    sget-object p1, Lo/xhb;->a:Lo/xhb;

    .line 40
    .line 41
    return-object p1

    .line 42
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 43
    .line 44
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    throw p1
.end method
