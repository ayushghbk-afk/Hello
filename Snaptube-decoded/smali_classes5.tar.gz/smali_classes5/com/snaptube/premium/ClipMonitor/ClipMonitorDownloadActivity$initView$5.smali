.class final Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source ""

# interfaces
.implements Lo/c74;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;->L0()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lo/c74;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n\u00a2\u0006\u0004\u0008\u0002\u0010\u0003"
    }
    d2 = {
        "Lo/cr1;",
        "Lo/xhb;",
        "<anonymous>",
        "(Lo/cr1;)V"
    }
    k = 0x3
    mv = {
        0x2,
        0x0,
        0x0
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.snaptube.premium.ClipMonitor.ClipMonitorDownloadActivity$initView$5"
    f = "ClipMonitorDownloadActivity.kt"
    i = {}
    l = {
        0x57
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field label:I

.field final synthetic this$0:Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;


# direct methods
.method public constructor <init>(Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;Lkotlin/coroutines/Continuation;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->this$0:Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lo/xhb;",
            ">;"
        }
    .end annotation

    new-instance p1, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;

    iget-object v0, p0, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->this$0:Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;

    invoke-direct {p1, v0, p2}, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;-><init>(Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;Lkotlin/coroutines/Continuation;)V

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lo/cr1;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->invoke(Lo/cr1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invoke(Lo/cr1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lo/cr1;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lo/xhb;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .line 2
    invoke-virtual {p0, p1, p2}, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object p1

    check-cast p1, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;

    sget-object p2, Lo/xhb;->a:Lo/xhb;

    invoke-virtual {p1, p2}, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    .line 1
    invoke-static {}, Lo/o85;->f()Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget v1, p0, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->label:I

    .line 6
    .line 7
    const/4 v2, 0x1

    .line 8
    if-eqz v1, :cond_1

    .line 9
    .line 10
    if-ne v1, v2, :cond_0

    .line 11
    .line 12
    invoke-static {p1}, Lkotlin/c;->b(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 19
    .line 20
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    throw p1

    .line 24
    :cond_1
    invoke-static {p1}, Lkotlin/c;->b(Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iget-object p1, p0, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->this$0:Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;

    .line 28
    .line 29
    invoke-static {p1}, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;->G0(Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;)Lcom/snaptube/premium/search/viewmodel/ClipboardLinkViewModel;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    iget-object v1, p0, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->this$0:Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;

    .line 34
    .line 35
    invoke-static {v1}, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;->H0(Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    if-nez v3, :cond_2

    .line 40
    .line 41
    const-string v3, "url"

    .line 42
    .line 43
    invoke-static {v3}, Lo/n85;->x(Ljava/lang/String;)V

    .line 44
    .line 45
    .line 46
    const/4 v3, 0x0

    .line 47
    :cond_2
    iput v2, p0, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->label:I

    .line 48
    .line 49
    const-string v2, "outside_clipboard"

    .line 50
    .line 51
    invoke-virtual {p1, v1, v3, v2, p0}, Lcom/snaptube/premium/search/viewmodel/ClipboardLinkViewModel;->T(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    if-ne p1, v0, :cond_3

    .line 56
    .line 57
    return-object v0

    .line 58
    :cond_3
    :goto_0
    check-cast p1, Ljava/lang/String;

    .line 59
    .line 60
    if-eqz p1, :cond_4

    .line 61
    .line 62
    iget-object v0, p0, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5;->this$0:Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;

    .line 63
    .line 64
    new-instance v1, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5$a;

    .line 65
    .line 66
    invoke-direct {v1, v0}, Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity$initView$5$a;-><init>(Lcom/snaptube/premium/ClipMonitor/ClipMonitorDownloadActivity;)V

    .line 67
    .line 68
    .line 69
    invoke-static {v0, p1, v1}, Lo/fy4;->j(Landroid/app/Activity;Ljava/lang/String;Lo/g1a;)V

    .line 70
    .line 71
    .line 72
    :cond_4
    sget-object p1, Lo/xhb;->a:Lo/xhb;

    .line 73
    .line 74
    return-object p1
.end method
