.class public final enum Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;
.super Ljava/lang/Enum;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/wandoujia/base/config/util/FileSizeCalUtils;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "SizeUnit"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u000c\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0008\u0008\u0008\u0086\u0081\u0002\u0018\u00002\u0008\u0012\u0004\u0012\u00020\u00000\u0001B\t\u0008\u0002\u00a2\u0006\u0004\u0008\u0002\u0010\u0003j\u0002\u0008\u0004j\u0002\u0008\u0005j\u0002\u0008\u0006j\u0002\u0008\u0007j\u0002\u0008\u0008\u00a8\u0006\t"
    }
    d2 = {
        "Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;",
        "",
        "<init>",
        "(Ljava/lang/String;I)V",
        "BYTE",
        "KB",
        "MB",
        "GB",
        "TB",
        "base-config_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x0,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field private static final synthetic $ENTRIES:Lo/y43;

.field private static final synthetic $VALUES:[Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

.field public static final enum BYTE:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

.field public static final enum GB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

.field public static final enum KB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

.field public static final enum MB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

.field public static final enum TB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 2
    .line 3
    const-string v1, "BYTE"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;-><init>(Ljava/lang/String;I)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->BYTE:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 10
    .line 11
    new-instance v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 12
    .line 13
    const-string v1, "KB"

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    invoke-direct {v0, v1, v2}, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;-><init>(Ljava/lang/String;I)V

    .line 17
    .line 18
    .line 19
    sput-object v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->KB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 20
    .line 21
    new-instance v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 22
    .line 23
    const-string v1, "MB"

    .line 24
    .line 25
    const/4 v2, 0x2

    .line 26
    invoke-direct {v0, v1, v2}, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;-><init>(Ljava/lang/String;I)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->MB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 30
    .line 31
    new-instance v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 32
    .line 33
    const-string v1, "GB"

    .line 34
    .line 35
    const/4 v2, 0x3

    .line 36
    invoke-direct {v0, v1, v2}, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;-><init>(Ljava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    sput-object v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->GB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 40
    .line 41
    new-instance v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 42
    .line 43
    const-string v1, "TB"

    .line 44
    .line 45
    const/4 v2, 0x4

    .line 46
    invoke-direct {v0, v1, v2}, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;-><init>(Ljava/lang/String;I)V

    .line 47
    .line 48
    .line 49
    sput-object v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->TB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 50
    .line 51
    invoke-static {}, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->l()[Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    sput-object v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->$VALUES:[Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 56
    .line 57
    invoke-static {v0}, Lkotlin/enums/a;->a([Ljava/lang/Enum;)Lo/y43;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    sput-object v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->$ENTRIES:Lo/y43;

    .line 62
    .line 63
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static getEntries()Lo/y43;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lo/y43;"
        }
    .end annotation

    .annotation build Lorg/jetbrains/annotations/NotNull;
    .end annotation

    .line 1
    sget-object v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->$ENTRIES:Lo/y43;

    return-object v0
.end method

.method public static final synthetic l()[Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;
    .locals 3

    .line 1
    const/4 v0, 0x5

    new-array v0, v0, [Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    sget-object v1, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->BYTE:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->KB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    const/4 v2, 0x1

    aput-object v1, v0, v2

    sget-object v1, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->MB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    const/4 v2, 0x2

    aput-object v1, v0, v2

    sget-object v1, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->GB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    const/4 v2, 0x3

    aput-object v1, v0, v2

    sget-object v1, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->TB:Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    const/4 v2, 0x4

    aput-object v1, v0, v2

    return-object v0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;
    .locals 1

    .line 1
    const-class v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 2
    .line 3
    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 8
    .line 9
    return-object p0
.end method

.method public static values()[Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;
    .locals 1

    .line 1
    sget-object v0, Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;->$VALUES:[Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, [Lcom/wandoujia/base/config/util/FileSizeCalUtils$SizeUnit;

    .line 8
    .line 9
    return-object v0
.end method
