.class public final Lcom/google/android/material/R$drawable;
.super Ljava/lang/Object;
.source ""


# static fields
.field public static final abc_ab_share_pack_mtrl_alpha:I = 0x7f080043

.field public static final abc_action_bar_item_background_material:I = 0x7f080044

.field public static final abc_btn_borderless_material:I = 0x7f080045

.field public static final abc_btn_check_material:I = 0x7f080046

.field public static final abc_btn_check_material_anim:I = 0x7f080047

.field public static final abc_btn_check_to_on_mtrl_000:I = 0x7f080048

.field public static final abc_btn_check_to_on_mtrl_015:I = 0x7f080049

.field public static final abc_btn_colored_material:I = 0x7f08004a

.field public static final abc_btn_default_mtrl_shape:I = 0x7f08004b

.field public static final abc_btn_radio_material:I = 0x7f08004c

.field public static final abc_btn_radio_material_anim:I = 0x7f08004d

.field public static final abc_btn_radio_to_on_mtrl_000:I = 0x7f08004e

.field public static final abc_btn_radio_to_on_mtrl_015:I = 0x7f08004f

.field public static final abc_btn_switch_to_on_mtrl_00001:I = 0x7f080050

.field public static final abc_btn_switch_to_on_mtrl_00012:I = 0x7f080051

.field public static final abc_cab_background_internal_bg:I = 0x7f080052

.field public static final abc_cab_background_top_material:I = 0x7f080053

.field public static final abc_cab_background_top_mtrl_alpha:I = 0x7f080054

.field public static final abc_control_background_material:I = 0x7f080055

.field public static final abc_dialog_material_background:I = 0x7f080056

.field public static final abc_edit_text_material:I = 0x7f080057

.field public static final abc_ic_ab_back_material:I = 0x7f080058

.field public static final abc_ic_arrow_drop_right_black_24dp:I = 0x7f080059

.field public static final abc_ic_clear_material:I = 0x7f08005a

.field public static final abc_ic_commit_search_api_mtrl_alpha:I = 0x7f08005b

.field public static final abc_ic_go_search_api_material:I = 0x7f08005c

.field public static final abc_ic_menu_copy_mtrl_am_alpha:I = 0x7f08005d

.field public static final abc_ic_menu_cut_mtrl_alpha:I = 0x7f08005e

.field public static final abc_ic_menu_overflow_material:I = 0x7f08005f

.field public static final abc_ic_menu_paste_mtrl_am_alpha:I = 0x7f080060

.field public static final abc_ic_menu_selectall_mtrl_alpha:I = 0x7f080061

.field public static final abc_ic_menu_share_mtrl_alpha:I = 0x7f080062

.field public static final abc_ic_search_api_material:I = 0x7f080063

.field public static final abc_ic_voice_search_api_material:I = 0x7f080064

.field public static final abc_item_background_holo_dark:I = 0x7f080065

.field public static final abc_item_background_holo_light:I = 0x7f080066

.field public static final abc_list_divider_material:I = 0x7f080067

.field public static final abc_list_divider_mtrl_alpha:I = 0x7f080068

.field public static final abc_list_focused_holo:I = 0x7f080069

.field public static final abc_list_longpressed_holo:I = 0x7f08006a

.field public static final abc_list_pressed_holo_dark:I = 0x7f08006b

.field public static final abc_list_pressed_holo_light:I = 0x7f08006c

.field public static final abc_list_selector_background_transition_holo_dark:I = 0x7f08006d

.field public static final abc_list_selector_background_transition_holo_light:I = 0x7f08006e

.field public static final abc_list_selector_disabled_holo_dark:I = 0x7f08006f

.field public static final abc_list_selector_disabled_holo_light:I = 0x7f080070

.field public static final abc_list_selector_holo_dark:I = 0x7f080071

.field public static final abc_list_selector_holo_light:I = 0x7f080072

.field public static final abc_menu_hardkey_panel_mtrl_mult:I = 0x7f080073

.field public static final abc_popup_background_mtrl_mult:I = 0x7f080074

.field public static final abc_ratingbar_indicator_material:I = 0x7f080075

.field public static final abc_ratingbar_material:I = 0x7f080076

.field public static final abc_ratingbar_small_material:I = 0x7f080077

.field public static final abc_scrubber_control_off_mtrl_alpha:I = 0x7f080078

.field public static final abc_scrubber_control_to_pressed_mtrl_000:I = 0x7f080079

.field public static final abc_scrubber_control_to_pressed_mtrl_005:I = 0x7f08007a

.field public static final abc_scrubber_primary_mtrl_alpha:I = 0x7f08007b

.field public static final abc_scrubber_track_mtrl_alpha:I = 0x7f08007d

.field public static final abc_seekbar_thumb_material:I = 0x7f08007e

.field public static final abc_seekbar_tick_mark_material:I = 0x7f08007f

.field public static final abc_seekbar_track_material:I = 0x7f080080

.field public static final abc_spinner_mtrl_am_alpha:I = 0x7f080081

.field public static final abc_spinner_textfield_background_material:I = 0x7f080082

.field public static final abc_switch_thumb_material:I = 0x7f080085

.field public static final abc_switch_track_mtrl_alpha:I = 0x7f080086

.field public static final abc_tab_indicator_material:I = 0x7f080087

.field public static final abc_tab_indicator_mtrl_alpha:I = 0x7f080088

.field public static final abc_text_cursor_material:I = 0x7f080089

.field public static final abc_textfield_activated_mtrl_alpha:I = 0x7f08008d

.field public static final abc_textfield_default_mtrl_alpha:I = 0x7f08008e

.field public static final abc_textfield_search_activated_mtrl_alpha:I = 0x7f08008f

.field public static final abc_textfield_search_default_mtrl_alpha:I = 0x7f080090

.field public static final abc_textfield_search_material:I = 0x7f080091

.field public static final abc_vector_test:I = 0x7f08007c

.field public static final avd_hide_password:I = 0x7f0800bd

.field public static final avd_show_password:I = 0x7f0800be

.field public static final btn_checkbox_checked_mtrl:I = 0x7f080172

.field public static final btn_checkbox_checked_to_unchecked_mtrl_animation:I = 0x7f080173

.field public static final btn_checkbox_unchecked_mtrl:I = 0x7f080174

.field public static final btn_checkbox_unchecked_to_checked_mtrl_animation:I = 0x7f080175

.field public static final btn_radio_off_mtrl:I = 0x7f080187

.field public static final btn_radio_off_to_on_mtrl_animation:I = 0x7f080188

.field public static final btn_radio_on_mtrl:I = 0x7f080189

.field public static final btn_radio_on_to_off_mtrl_animation:I = 0x7f08018a

.field public static final design_fab_background:I = 0x7f0801b7

.field public static final design_ic_visibility:I = 0x7f0801b8

.field public static final design_ic_visibility_off:I = 0x7f0801b9

.field public static final design_password_eye:I = 0x7f0801ba

.field public static final design_snackbar_background:I = 0x7f0801bb

.field public static final ic_clock_black_24dp:I = 0x7f080335

.field public static final ic_keyboard_black_24dp:I = 0x7f0803cc

.field public static final ic_mtrl_checked_circle:I = 0x7f080406

.field public static final ic_mtrl_chip_checked_black:I = 0x7f080407

.field public static final ic_mtrl_chip_checked_circle:I = 0x7f080408

.field public static final ic_mtrl_chip_close_circle:I = 0x7f080409

.field public static final material_cursor_drawable:I = 0x7f0805a9

.field public static final material_ic_calendar_black_24dp:I = 0x7f0805ab

.field public static final material_ic_clear_black_24dp:I = 0x7f0805ac

.field public static final material_ic_edit_black_24dp:I = 0x7f0805ad

.field public static final material_ic_keyboard_arrow_left_black_24dp:I = 0x7f0805ae

.field public static final material_ic_keyboard_arrow_next_black_24dp:I = 0x7f0805af

.field public static final material_ic_keyboard_arrow_previous_black_24dp:I = 0x7f0805b0

.field public static final material_ic_keyboard_arrow_right_black_24dp:I = 0x7f0805b1

.field public static final material_ic_menu_arrow_down_black_24dp:I = 0x7f0805b2

.field public static final material_ic_menu_arrow_up_black_24dp:I = 0x7f0805b3

.field public static final mtrl_dialog_background:I = 0x7f080650

.field public static final mtrl_dropdown_arrow:I = 0x7f080651

.field public static final mtrl_ic_arrow_drop_down:I = 0x7f080652

.field public static final mtrl_ic_arrow_drop_up:I = 0x7f080653

.field public static final mtrl_ic_cancel:I = 0x7f080654

.field public static final mtrl_ic_error:I = 0x7f080655

.field public static final mtrl_navigation_bar_item_background:I = 0x7f080656

.field public static final mtrl_popupmenu_background:I = 0x7f080657

.field public static final mtrl_popupmenu_background_dark:I = 0x7f080658

.field public static final mtrl_tabs_default_indicator:I = 0x7f080659

.field public static final navigation_empty_icon:I = 0x7f08065d

.field public static final notification_action_background:I = 0x7f080660

.field public static final notification_bg:I = 0x7f080661

.field public static final notification_bg_low:I = 0x7f080662

.field public static final notification_bg_low_normal:I = 0x7f080663

.field public static final notification_bg_low_pressed:I = 0x7f080664

.field public static final notification_bg_normal:I = 0x7f080666

.field public static final notification_bg_normal_pressed:I = 0x7f080667

.field public static final notification_icon_background:I = 0x7f080668

.field public static final notification_template_icon_bg:I = 0x7f080669

.field public static final notification_template_icon_low_bg:I = 0x7f08066c

.field public static final notification_tile_bg:I = 0x7f080672

.field public static final notify_panel_notification_icon_bg:I = 0x7f080673

.field public static final test_custom_background:I = 0x7f08079f

.field public static final tooltip_frame_dark:I = 0x7f0807ae

.field public static final tooltip_frame_light:I = 0x7f0807af
