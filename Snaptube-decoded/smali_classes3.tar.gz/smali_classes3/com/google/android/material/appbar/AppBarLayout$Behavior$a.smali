.class public abstract Lcom/google/android/material/appbar/AppBarLayout$Behavior$a;
.super Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$d;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/appbar/AppBarLayout$Behavior;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/google/android/material/appbar/AppBarLayout$BaseBehavior$d;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
