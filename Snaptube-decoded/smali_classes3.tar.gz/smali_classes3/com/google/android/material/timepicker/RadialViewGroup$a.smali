.class public Lcom/google/android/material/timepicker/RadialViewGroup$a;
.super Ljava/lang/Object;
.source ""

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/timepicker/RadialViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic b:Lcom/google/android/material/timepicker/RadialViewGroup;


# direct methods
.method public constructor <init>(Lcom/google/android/material/timepicker/RadialViewGroup;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lcom/google/android/material/timepicker/RadialViewGroup$a;->b:Lcom/google/android/material/timepicker/RadialViewGroup;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/google/android/material/timepicker/RadialViewGroup$a;->b:Lcom/google/android/material/timepicker/RadialViewGroup;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcom/google/android/material/timepicker/RadialViewGroup;->o0()V

    .line 4
    .line 5
    .line 6
    return-void
.end method
