.class public interface abstract Lcom/inmobi/media/O0;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method
