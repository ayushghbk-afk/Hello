.class public final Lcom/inmobi/media/Lk;
.super Lcom/inmobi/media/D2;
.source ""


# instance fields
.field private final content:Lcom/inmobi/media/core/config/models/SignalsConfig;
    .annotation build Lorg/jetbrains/annotations/Nullable;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/inmobi/media/D2;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final a()Lcom/inmobi/media/core/config/models/Config;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/inmobi/media/Lk;->content:Lcom/inmobi/media/core/config/models/SignalsConfig;

    .line 2
    .line 3
    return-object v0
.end method
