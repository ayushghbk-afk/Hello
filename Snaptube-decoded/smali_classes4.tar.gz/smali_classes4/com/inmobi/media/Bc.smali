.class public abstract Lcom/inmobi/media/Bc;
.super Ljava/lang/Object;
.source ""


# direct methods
.method public static final a(Ljava/lang/String;)Lcom/inmobi/media/Ac;
    .locals 2

    .line 1
    const-string v0, "logLevel"

    .line 2
    .line 3
    invoke-static {p0, v0}, Lo/n85;->g(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "DEBUG"

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    invoke-static {p0, v0, v1}, Lo/dla;->D(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    sget-object p0, Lcom/inmobi/media/Ac;->b:Lcom/inmobi/media/Ac;

    .line 16
    .line 17
    return-object p0

    .line 18
    :cond_0
    const-string v0, "ERROR"

    .line 19
    .line 20
    invoke-static {p0, v0, v1}, Lo/dla;->D(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    sget-object p0, Lcom/inmobi/media/Ac;->c:Lcom/inmobi/media/Ac;

    .line 27
    .line 28
    return-object p0

    .line 29
    :cond_1
    const-string v0, "INFO"

    .line 30
    .line 31
    invoke-static {p0, v0, v1}, Lo/dla;->D(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_2

    .line 36
    .line 37
    sget-object p0, Lcom/inmobi/media/Ac;->a:Lcom/inmobi/media/Ac;

    .line 38
    .line 39
    return-object p0

    .line 40
    :cond_2
    const-string v0, "STATE"

    .line 41
    .line 42
    invoke-static {p0, v0, v1}, Lo/dla;->D(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 43
    .line 44
    .line 45
    move-result p0

    .line 46
    if-eqz p0, :cond_3

    .line 47
    .line 48
    sget-object p0, Lcom/inmobi/media/Ac;->d:Lcom/inmobi/media/Ac;

    .line 49
    .line 50
    return-object p0

    .line 51
    :cond_3
    sget-object p0, Lcom/inmobi/media/Ac;->c:Lcom/inmobi/media/Ac;

    .line 52
    .line 53
    return-object p0
.end method
