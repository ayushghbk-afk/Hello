.class public interface abstract Lcom/inmobi/media/Fq;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(D)Ljava/lang/String;
.end method

.method public abstract a(ID)Ljava/lang/String;
.end method
