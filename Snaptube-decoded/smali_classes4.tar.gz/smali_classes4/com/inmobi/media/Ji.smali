.class public interface abstract Lcom/inmobi/media/Ji;
.super Ljava/lang/Object;
.source ""


# virtual methods
.method public abstract a(Ljava/lang/String;)V
.end method

.method public abstract a()Z
.end method

.method public abstract c()Z
.end method

.method public abstract getViewTouchTimestamp()J
.end method
