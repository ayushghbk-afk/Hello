.class public final Lcom/inmobi/media/Lg;
.super Lcom/inmobi/media/j;
.source ""


# static fields
.field public static final a:Lcom/inmobi/media/Lg;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lcom/inmobi/media/Lg;

    .line 2
    .line 3
    invoke-direct {v0}, Lcom/inmobi/media/Lg;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lcom/inmobi/media/Lg;->a:Lcom/inmobi/media/Lg;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Lcom/inmobi/media/j;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method
